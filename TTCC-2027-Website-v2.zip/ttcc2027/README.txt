TTCC 2027 WEBSITE

File utama: index.html
Website ini statis dan siap diunggah ke Netlify.

Cara termudah:
1. Buka https://app.netlify.com/drop
2. Drag folder ttcc2027 atau file ZIP ke halaman tersebut.
3. Netlify akan membuat URL publik.

Semua tombol Proposal, Juknis, dan Pendaftaran sudah menggunakan link yang diberikan.
